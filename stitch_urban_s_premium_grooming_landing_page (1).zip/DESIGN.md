---
name: Urban's Industrial Luxury
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#d0c5af'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#99907c'
  outline-variant: '#4d4635'
  surface-tint: '#e9c349'
  primary: '#f2ca50'
  on-primary: '#3c2f00'
  primary-container: '#d4af37'
  on-primary-container: '#554300'
  inverse-primary: '#735c00'
  secondary: '#c8c6c5'
  on-secondary: '#313030'
  secondary-container: '#474746'
  on-secondary-container: '#b7b5b4'
  tertiary: '#cfcece'
  on-tertiary: '#2f3131'
  tertiary-container: '#b3b3b3'
  on-tertiary-container: '#444545'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe088'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#e3e2e2'
  tertiary-fixed-dim: '#c7c6c6'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#464747'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-lg:
    fontFamily: Bebas Neue
    fontSize: 80px
    fontWeight: '400'
    lineHeight: 80px
    letterSpacing: 0.02em
  headline-lg:
    fontFamily: Bebas Neue
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 52px
    letterSpacing: 0.04em
  headline-lg-mobile:
    fontFamily: Bebas Neue
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 40px
    letterSpacing: 0.04em
  headline-md:
    fontFamily: Bebas Neue
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 36px
    letterSpacing: 0.04em
  title-lg:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1200px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 64px
---

## Brand & Style

The design system embodies "Industrial Luxury"—a fusion of raw, masculine textures with the refined precision of high-end grooming. It is tailored for the modern man in Kanasín who seeks an upscale sanctuary. The aesthetic is grounded in a **Minimalist-Industrial** approach: heavy on whitespace, structured by rigid grids, and elevated through sophisticated lighting effects.

The UI should feel like a premium barbershop interior: dark, moody, and meticulously organized. It prioritizes high-contrast focal points and a confident, authoritative presence. The emotional response is one of trust, exclusivity, and professional mastery.

## Colors

The palette is strictly dark-mode to reflect the "Industrial Luxury" theme. 

- **Primary (Amber Gold):** Used sparingly for high-intent actions, key highlights, and brand reinforcement. It represents the "premium" aspect of the service.
- **Secondary (Charcoal):** Used for elevated surfaces and containers to create depth against the pure black background.
- **Neutral (Matte Black & White):** Matte Black (#0A0A0A) serves as the base canvas. White is reserved for primary content, while Light Gray (#A0A0A0) handles secondary metadata and borders.

The "Gold" should be applied with high intent—much like a brass fixture in a dark room. Avoid large washes of gold; prefer thin lines, icons, and text buttons.

## Typography

The typographic hierarchy relies on the tension between the tall, architectural **Bebas Neue** and the clean, contemporary **Hanken Grotesk**. 

- **Headlines:** Always use Bebas Neue. It should be set in Uppercase to maintain the industrial, "stenciled" look of a premium workshop. Increased letter spacing (0.04em) is required for larger titles.
- **Body Text:** Hanken Grotesk provides a sharp, technical readability that balances the display type. 
- **Language:** All copy is in Spanish, ensuring the tone remains "Cercano pero Profesional" (Close yet Professional). Use formal "Usted" where appropriate to maintain the upscale feel.

## Layout & Spacing

This design system utilizes a **12-column Fixed Grid** for desktop and a **4-column Fluid Grid** for mobile. The layout philosophy is rooted in generous negative space, allowing imagery of haircuts and textures to breathe.

- **Rhythm:** All vertical spacing should be multiples of 8px.
- **Margins:** Desktop uses wide 64px margins to create a "gallery" feel.
- **Sectioning:** Use large vertical padding (80px - 120px) between homepage sections to emphasize a slow, luxurious scrolling experience.

## Elevation & Depth

In a dark, industrial theme, depth is created through **Tonal Layering** and **Low-Contrast Outlines** rather than traditional shadows.

1.  **Level 0 (Base):** #0A0A0A (Matte Black).
2.  **Level 1 (Card/Container):** #121212 with a 1px solid border of #222222.
3.  **Level 2 (Dropdowns/Modals):** #1A1A1A with a 1px solid border of #D4AF37 at 30% opacity.

**Texture:** Apply a subtle noise or "leather grain" overlay at 3% opacity on the Level 0 background to eliminate the "flat digital" feel and introduce a tactile, industrial quality.

## Shapes

The shape language is **Structured and Sharp**. 

- **Buttons & Inputs:** Use the "Soft" setting (0.25rem / 4px) to prevent the UI from feeling dangerously sharp while maintaining a masculine, architectural rigidity.
- **Images:** All portfolio photography should have 0px radius (Sharp) to mimic framed gallery prints.
- **Dividers:** Use thin, 1px horizontal lines in #222222 to separate content areas.

## Components

### Buttons
- **Primary:** Background #D4AF37 (Amber Gold), Text #0A0A0A. FontWeight: Bold. Hover state: Brighten Amber by 10%.
- **Secondary:** Transparent background, 2px Border #D4AF37, Text #D4AF37. 
- **Tertiary:** Transparent, Text #FFFFFF, Underline on hover.

### Input Fields
- **Style:** Background #121212, Border-bottom only (2px) in #A0A0A0. When focused, the border-bottom transitions to #D4AF37.
- **Labels:** Use `label-sm` (Uppercase, Hanken Grotesk).

### Cards
- Used for service listings (Cortes, Barba, Tratamientos).
- Background #121212.
- 1px border #222222.
- Hover state: Border color changes to #D4AF37.

### Specialized Components
- **Booking Widget:** A high-contrast sticky bar or floating action button in Amber Gold, ensuring "Reservar Cita" is always accessible.
- **Service List:** Minimalist rows with the service name in `title-lg` and the price in `title-lg` (Amber Gold), separated by a dotted leader or simple whitespace.